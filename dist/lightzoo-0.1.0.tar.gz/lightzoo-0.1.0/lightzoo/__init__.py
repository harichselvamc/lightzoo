# lightzoo/__init__.py

"""
LightZoo: A Lightweight Model Zoo for Prototyping and Research
"""

__version__ = "0.1.0"
