# tests/__init__.py

"""
Test suite for LightZoo.
Use `pytest` to run all unit tests.
"""
