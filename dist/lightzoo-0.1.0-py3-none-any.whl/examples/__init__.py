# examples/__init__.py

"""
Example scripts to demonstrate training, evaluation, and usage of LightZoo models.
"""
